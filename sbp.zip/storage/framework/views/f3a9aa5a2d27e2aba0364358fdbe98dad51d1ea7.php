<button class="btn btn-<?php echo e($type); ?> mt-3" type="<?php echo e(($for) ?? 'button'); ?>">
	<?php echo e($text); ?>

</button><?php /**PATH C:\Xampp\htdocs\sbp\resources\views/components/button.blade.php ENDPATH**/ ?>