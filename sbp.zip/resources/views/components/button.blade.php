<button class="btn btn-{{ $type }} mt-3" type="{{ ($for) ?? 'button' }}">
	{{ $text }}
</button>