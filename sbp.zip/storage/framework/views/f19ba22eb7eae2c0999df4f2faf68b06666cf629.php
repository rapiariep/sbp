<li class="nav-item<?php echo e($active); ?>">
    <a class="nav-link" href="<?php echo e($url); ?>">
        <i class="fas fa-fw fa-<?php echo e($icon); ?>"></i>
        <span><?php echo e($text); ?></span>
    </a>
</li><?php /**PATH C:\Xampp\htdocs\sbp\resources\views/components/nav-link.blade.php ENDPATH**/ ?>